var drySignConfiguration ={};

drySignConfiguration.corperatEmailList= ['hovsltd.com','lexicode.com','banctec.fr',
	'hgmfund.com','banctec.com','sourcehov.com','sourcehov.com',
	'hovservices.com','sourcehov.com','banctec.in','banctec.in',
	'srcp.com','banctec.co.uk','transcentra.com','rustconsulting.com',
	'transcentra.in','sourcehovtax.com','banctec.de','exelatech.com','banctec.se,banctec.de',
	'banctec.nl','bayareacredit.com','sourcehovtax.com','lexicode.com','ersgroup.com',
	'banctec.se','banctec.ca','mgdcare.com','novitex.com','rule14.com',
	'exelaonline.com'];

